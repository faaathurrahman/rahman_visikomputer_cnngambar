- perintah untuk mengaktifkan conda virtual
$ conda activate python-img-classification

- perintah untuk jalankan jupyter
$ jupyter notebook

- jika ada module yang tidak ada di virtual, maka pastikan
saat install module tersebut anda sedang di virtual tersebut.
bukti anda sedang di terminal virtual tersebut adalah tanda
(python-img-classificatio)
jika sudah maka anda bisa menjalankan perintah install module seperti biasa
misalkan $ pip install matplotlib
jika sudah buka jupyter notebook, selanjutnya restart kernelnya